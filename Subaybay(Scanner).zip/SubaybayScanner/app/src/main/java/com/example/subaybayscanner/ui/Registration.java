package com.example.subaybayscanner.ui;

import android.app.Activity;

public class Registration extends Activity {
}
